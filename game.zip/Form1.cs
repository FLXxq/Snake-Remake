﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace game
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void файлToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

      

        private void настройкиToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            oprogramme программа = new oprogramme();
            программа.ShowDialog();
        }

        private void button1_Click_1(object sender, EventArgs e)
        { 
            Process iStartProcess = new Process(); 
            iStartProcess.StartInfo.FileName = @"..\..\Snake Remake\Snake Remake.exe";  
            iStartProcess.Start(); 
            iStartProcess.WaitForExit(120000); 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
